/*$(document).ready(function(){
  	alert('jquery loaded');

  	return false;
  });

	$('#cobab').click(function(){
	alert('licked');

  return false;
	}*/



  /*function save()
      {
        /*var url;
        if(save_method == 'add')
        {
            url = "<?php //echo base_url('admin/kategori_add/')?>";
        }
        else
        {
            url = "<?php //echo base_url('admin/kategori_update/')?>";
        }*/

         // ajax adding data to database
            /*$.ajax({
              'method'  : "POST",
              'data'    : $('#edKateg').serialize(),
              'url'     : '<?//= base_url('admin/update_kategori');?>',
              // dataType: "JSON",
              'success' : function(data){
                //if success close modal and reload ajax table
                $('#modal').modal('hide');
                location.reload();// for reload a page
              },
              'error'   : function (err){
                  alert('Error adding / update data');
              }
          });
      }*/