<div class="sub-banner" >
  <div class="container" style="padding-top:10%;color:white;">
    <span>Kategori</span>
    <h2 style="font-weight:600;">Semua Kategori yang Tersedia</h2>
  </div>
  <div class="container filter-box" style="text-align:left;font-size:120%;line-height:2;">
    <div class="row company-itembody">
      <div class="col-md-4 category-box">
          <i class="fa fa-3x fa-bank"></i>
          <h3>Teknologi</h3>
          <hr/>
      </div>
      <div class="col-md-3 category-box">
          <i class="fa fa-3x fa-automobile"></i>
          <h3>Otomotif</h3>
          <hr/>
      </div>
      <div class="col-md-4 category-box">
          <i class="fa fa-3x fa-book"></i>
          <h3>Kerajinan</h3>
          <hr/>
      </div>
      <div class="col-md-3 category-box">
          <i class="fa fa-3x fa-cubes"></i>
          <h3>Material</h3>
          <hr/>
      </div>
      <div class="col-md-3 category-box">
          <i class="fa fa-3x fa-diamond"></i>
          <h3>Logam</h3>
          <hr/>
      </div>
      <div class="col-md-5 category-box">
          <i class="fa fa-3x fa-flask"></i>
          <h3>Bahan Kimia</h3>
          <hr/>
      </div>
      <div class="col-md-4 category-box">
          <i class="fa fa-3x fa-bank"></i>
          <h3>Teknologi</h3>
          <hr/>
      </div>
      <div class="col-md-3 category-box">
          <i class="fa fa-3x fa-automobile"></i>
          <h3>Otomotif</h3>
          <hr/>
      </div>
      <div class="col-md-4 category-box">
          <i class="fa fa-3x fa-book"></i>
          <h3>Kerajinan</h3>
          <hr/>
      </div>
      <div class="col-md-3 category-box">
          <i class="fa fa-3x fa-cubes"></i>
          <h3>Material</h3>
          <hr/>
      </div>
      <div class="col-md-3 category-box">
          <i class="fa fa-3x fa-diamond"></i>
          <h3>Logam</h3>
          <hr/>
      </div>
      <div class="col-md-5 category-box">
          <i class="fa fa-3x fa-flask"></i>
          <h3>Bahan Kimia</h3>
          <hr/>
      </div>
    </div>
    <div class="row company-action">
      <div class="col-md-8 pull-left">
        <h4 style="margin-top:20px;">Bagikan di
          <span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-facebook fa-stack-1x fa-inverse"></i></span>
          <span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-twitter fa-stack-1x fa-inverse"></i></span>
          <span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-google-plus fa-stack-1x fa-inverse"></i></span>
          <span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-linkedin fa-stack-1x fa-inverse"></i></span>
        </h4>
      </div>
    </div>
</div>

<div class="container-fluid section1">
    <div class="container">
        <div class="row section1-header">

        </div>

        <br>
    </div>
</div>
